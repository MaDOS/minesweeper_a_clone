HOW TO USE
----------

Add a reference to the theme assembly.

In your WPF project's App.xaml or Application.xaml file, add the following code to the <Application.Resources> section.

      <ResourceDictionary Source="/ReuxablesLegacy;component/???.xaml" />

Replace ??? with one of the following options:
candy
edge
frog
inc
mercury
metal
sleek

For help on using the additional styles available in Mercury, see the sample project.



For further help:

FAQ - www.nukeation.com/faq.aspx 
SAMPLE CODE - www.nukeation.com/samples.aspx